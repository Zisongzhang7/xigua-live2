import React, { useState, useEffect } from 'react';
import {
  ChevronLeft,
  Save,
  Plus,
  Trash2,
  Clock,
  List,
  Search,
  X,
  Tag as TagIcon,
  GripVertical,
  Settings2,
  FileStack,
  Info,
  Check,
  AlertCircle,
  Video,
  Monitor,
  LayoutList,
  Sparkles,
  Link2,
  Users,
  Play,
  PictureInPicture2,
  FolderOpen,
  Copy,
  Gift,
  MessageSquare,
  Mic,
  PlusCircle
} from 'lucide-react';
import { InteractionTemplate, InteractiveResource, InteractionCategory, InteractionItem, LiveStream } from '../types';
import { COMMON_LABELS } from '../App';
import {
  ResourceSelectionModal,
  ModeTab,
  InteractionToggle,
  CascadingSearchSelector,
  SearchableSelector,
  SearchableMultiSelect,
  InteractionItemView,
  InteractionCategoryGroup,
  DB
} from './LiveSetupComponents';
import { QuizCard, QuizStatus } from './QuizCard';
import { VoteCard, VoteStatus } from './VoteCard';
import { DebateCard, DebateStatus } from './DebateCard';
import { EliminationCard, EliminationStatus } from './EliminationCard';
import { GandiCard, GandiStatus } from './GandiCard';
import { LinkCard, LinkStatus } from './LinkCard';
import { ModelCard, ModelStatus } from './ModelCard';
import { SliceListCard, SliceListStatus } from './SliceListCard';

// Interaction Categories
const MAIN_CATEGORIES = [
  InteractionCategory.COURSE_SLICE,
  InteractionCategory.VIDEO,
  InteractionCategory.GANDI_EMBED,
  InteractionCategory.LINK
];

const OVERLAY_CATEGORIES = [
  InteractionCategory.QUIZ,
  InteractionCategory.DEBATE,
  InteractionCategory.ONE_STAND,
  InteractionCategory.VOTE,
  InteractionCategory.MODEL
];

interface InteractionState {
  status: any;
  votes: any;
  isExpanded: boolean;
}

interface EditInteractionTemplateViewProps {
  initialTemplate?: InteractionTemplate;
  resources: InteractiveResource[];
  onBack: () => void;
  onSave: (template: InteractionTemplate) => void;
  allLabels: string[];
}

const EditInteractionTemplateView: React.FC<EditInteractionTemplateViewProps> = ({
  initialTemplate,
  resources,
  onBack,
  onSave,
  allLabels
}) => {
  // Template Metadata State
  const [name, setName] = useState(initialTemplate?.name || '');
  const [selectedLabels, setSelectedLabels] = useState<string[]>(initialTemplate?.labels || []);
  const [newLabelInput, setNewLabelInput] = useState('');
  const [showLabelInput, setShowLabelInput] = useState(false);

  // Interaction Management State (Mirrors LiveSetupView)
  const [activeTab, setActiveTab] = useState<'LIST' | 'TIMELINE'>('TIMELINE');
  const [interactionsList, setInteractionsList] = useState<InteractionItem[]>([]);

  // Selection & Modal State
  const [isSelectionModalOpen, setSelectionModalOpen] = useState(false);
  const [selectionModalCategoryFilter, setSelectionModalCategoryFilter] = useState<InteractionCategory[] | undefined>(undefined);

  // Track Management State
  const [selectedMainTrackId, setSelectedMainTrackId] = useState<string | null>(null);
  const [draggedItemIndex, setDraggedItemIndex] = useState<number | null>(null);

  // Interaction Runtime State (for previews)
  const [interactionStates, setInteractionStates] = useState<Record<string, InteractionState>>({});

  // Mock "Live" state for compatibility with copied render logic
  const activeMainTrackId: string | null = null;
  const completedMainTrackIds = new Set<string>();

  // Initialize Data
  useEffect(() => {
    if (initialTemplate) {
      setName(initialTemplate.name);
      setSelectedLabels(initialTemplate.labels);

      if (initialTemplate.items && initialTemplate.items.length > 0) {
        setInteractionsList(initialTemplate.items);
        // Try to select the first MAIN track item if available to set context
        const firstMain = initialTemplate.items.find(i => i.track === 'MAIN');
        if (firstMain) setSelectedMainTrackId(firstMain.id);
      } else {
        setInteractionsList([]);
      }
    }
  }, [initialTemplate]);

  // --- Handlers (Ported from LiveSetupView) ---

  const getInteractionState = (id: string): InteractionState => {
    // Default to collapsed (isExpanded: false) as requested
    return interactionStates[id] || { status: 'IDLE', votes: {}, isExpanded: false };
  };

  const updateInteractionState = (id: string, updates: Partial<InteractionState>) => {
    setInteractionStates(prev => ({
      ...prev,
      [id]: { ...getInteractionState(id), ...updates }
    }));
  };

  const handleAddInteraction = (categories?: InteractionCategory[]) => {
    setSelectionModalCategoryFilter(categories);
    setSelectionModalOpen(true);
  };

  const handleResourceSelected = (resource: InteractiveResource) => {
    const isMainTrack = MAIN_CATEGORIES.includes(resource.category);

    // 1. Handle Course Slices (Explode into multiple items)
    if (resource.category === InteractionCategory.COURSE_SLICE && resource.config?.slices) {
      const sliceItems: InteractionItem[] = resource.config.slices.map((slice: any, index: number) => ({
        id: `tpl-slice-${Date.now()}-${index}`,
        title: `${resource.name} - ${slice.title}`,
        type: InteractionCategory.COURSE_SLICE,
        track: 'MAIN',
        time: new Date().toISOString(),
        config: {
          ...slice,
          lessonName: resource.name,
          sliceIndex: index + 1,
          sliceType: slice.type,
          className: resource.config.className,
          slices: resource.config.slices
        },
        triggerMode: 'MANUAL',
        duration: slice.duration || 300
      }));

      setInteractionsList(prev => {
        const newList = [...prev];
        if (selectedMainTrackId) {
          const idx = prev.findIndex(i => i.id === selectedMainTrackId);
          if (idx !== -1) {
            newList.splice(idx + 1, 0, ...sliceItems);
            return newList;
          }
        }
        return [...newList, ...sliceItems];
      });
      setSelectedMainTrackId(sliceItems[0].id);
      setSelectionModalOpen(false);
      return;
    }

    // 2. Handle Normal Items
    const newItem: InteractionItem = {
      id: `tpl-item-${Date.now()}`,
      title: resource.name,
      type: resource.category,
      track: isMainTrack ? 'MAIN' : 'OVERLAY',
      parentId: (isMainTrack ? undefined : selectedMainTrackId) || undefined,
      time: new Date().toISOString(),
      config: resource.config || {},
      triggerMode: 'MANUAL',
      duration: 300,
    };

    if (!isMainTrack && !selectedMainTrackId) {
      alert("请先选择一个主画面轨道内容，再添加叠加交互");
      return;
    }

    setInteractionsList(prev => {
      const newList = [...prev];
      if (isMainTrack && selectedMainTrackId) {
        const idx = prev.findIndex(i => i.id === selectedMainTrackId);
        if (idx !== -1) newList.splice(idx + 1, 0, newItem);
        else newList.push(newItem);
      } else {
        newList.push(newItem);
      }
      return newList;
    });

    if (isMainTrack) {
      setSelectedMainTrackId(newItem.id);
    }
    setSelectionModalOpen(false);
  };

  const handleDeleteInteraction = (id: string) => {
    if (window.confirm('确定要删除此交互项吗？')) {
      setInteractionsList(prev => prev.filter(item => item.id !== id && item.parentId !== id)); // Cascade delete children
      if (selectedMainTrackId === id) setSelectedMainTrackId(null);
    }
  };

  const handleClearInteractions = () => {
    if (window.confirm('确定要清空所有交互吗？')) {
      setInteractionsList([]);
      setSelectedMainTrackId(null);
    }
  }

  const handleUpdateInteraction = (id: string, updates: Partial<InteractionItem>) => {
    setInteractionsList(prev => prev.map(item =>
      item.id === id ? { ...item, ...updates } : item
    ));
  };

  // Drag & Drop
  const handleDragStart = (index: number) => setDraggedItemIndex(index);
  const handleDragOver = (e: React.DragEvent, index: number) => {
    e.preventDefault();
    if (draggedItemIndex === null || draggedItemIndex === index) return;

    // Check compatibility roughly
    const draggedItem = interactionsList[draggedItemIndex];
    const targetItem = interactionsList[index];
    if (draggedItem.track !== targetItem.track) return;

    const newItems = [...interactionsList];
    const [removed] = newItems.splice(draggedItemIndex, 1);
    newItems.splice(index, 0, removed);
    setInteractionsList(newItems);
    setDraggedItemIndex(index);
  };
  const handleDragEnd = () => setDraggedItemIndex(null);

  const handleAddCamera = () => {
    const newItem: InteractionItem = {
      id: `tpl-cam-${Date.now()}`,
      title: '直播流画面',
      type: InteractionCategory.CAMERA,
      track: 'MAIN',
      time: new Date().toISOString(),
      config: { audioSource: 'default', videoSource: 'default', pipEnabled: false },
      triggerMode: 'MANUAL',
      duration: 300
    };

    setInteractionsList(prev => {
      const newList = [...prev];
      if (selectedMainTrackId) {
        const idx = prev.findIndex(i => i.id === selectedMainTrackId);
        if (idx !== -1) {
          newList.splice(idx + 1, 0, newItem);
          return newList;
        }
      }
      newList.push(newItem);
      return newList;
    });
    setSelectedMainTrackId(newItem.id);
  };

  // Mock handlers replacing the Live equivalents
  const handleStartMainItem = (id: string) => setSelectedMainTrackId(id);
  const handleStopMainItem = (id: string) => { };

  // --- Main Save Handler ---
  const handleSaveTemplate = () => {
    if (!name.trim()) {
      alert('请输入模板名称');
      return;
    }

    const templateToSave: InteractionTemplate = {
      ...((initialTemplate || {}) as InteractionTemplate),
      id: initialTemplate?.id || `tpl-${Date.now()}`,
      name: name,
      labels: selectedLabels,
      items: interactionsList,
      interactionCount: interactionsList.length,
      creator: initialTemplate?.creator || 'Admin',
      modifiedAt: new Date().toLocaleString()
    };
    onSave(templateToSave);
  };

  const toggleLabel = (label: string) => {
    setSelectedLabels(prev =>
      prev.includes(label) ? prev.filter(l => l !== label) : [...prev, label]
    );
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#F0F2F5] flex flex-col animate-in slide-in-from-right duration-300 overflow-hidden">
      {/* 1. Header Toolbar */}
      <div className="bg-white border-b border-gray-200 px-6 py-3 flex justify-between items-center z-10 shadow-sm sticky top-0">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="p-2 hover:bg-gray-100 rounded-lg text-gray-500 transition-colors">
            <ChevronLeft size={20} />
          </button>
          <div className="h-6 w-px bg-gray-200"></div>
          <div>
            <h2 className="text-lg font-black text-gray-900 leading-none">编辑模板</h2>
            <p className="text-[10px] text-gray-400 font-medium mt-0.5 uppercase tracking-wider">Edit Template Configuration</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleSaveTemplate}
            className="flex items-center gap-2 px-6 py-2.5 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 active:scale-95 transition-all shadow-lg shadow-blue-200"
          >
            <Save size={18} /> 保存模板
          </button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto w-full p-6 space-y-6">
        {/* 2. Metadata Editor */}
        <div className="bg-white rounded-3xl border border-gray-100 shadow-sm p-8 space-y-8">
          <div className="flex items-center gap-3 border-l-4 border-blue-600 pl-4">
            <TagIcon size={18} className="text-blue-600" />
            <h2 className="text-base font-black text-gray-900 tracking-tight uppercase">模板基础信息</h2>
          </div>

          <div className="space-y-2 flex-1">
            <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest pl-1">内部展示名称</label>
            <div className="relative">
              <input
                type="text"
                placeholder="请输入资源在后台显示的名称..."
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-white border border-gray-200 rounded-2xl px-5 py-4 text-sm font-bold text-gray-900 focus:ring-4 focus:ring-blue-100 focus:border-blue-500 outline-none transition-all shadow-sm"
              />
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest pl-1">标签分类 (点击选择或新增)</label>
              <button
                onClick={() => setShowLabelInput(!showLabelInput)}
                className="text-[10px] font-black text-blue-600 flex items-center gap-1 hover:underline"
              >
                <PlusCircle size={12} /> 自定义标签
              </button>
            </div>

            {showLabelInput && (
              <div className="flex gap-2 animate-in slide-in-from-top-2 duration-200 mb-4">
                <input
                  autoFocus
                  type="text"
                  placeholder="输入新标签..."
                  value={newLabelInput}
                  onChange={(e) => setNewLabelInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      const val = newLabelInput.trim();
                      if (val) {
                        if (!selectedLabels.includes(val)) setSelectedLabels(prev => [...prev, val]);
                        setNewLabelInput('');
                        setShowLabelInput(false);
                      }
                    }
                  }}
                  className="flex-1 bg-gray-50 border border-blue-200 rounded-xl px-4 py-2 text-xs font-bold text-gray-900 outline-none"
                />
                <button
                  onClick={() => {
                    const val = newLabelInput.trim();
                    if (val) {
                      if (!selectedLabels.includes(val)) setSelectedLabels(prev => [...prev, val]);
                      setNewLabelInput('');
                      setShowLabelInput(false);
                    }
                  }}
                  className="px-4 py-2 bg-blue-600 text-white rounded-xl text-xs font-black"
                >
                  添加
                </button>
              </div>
            )}

            <div className="flex flex-wrap gap-2">
              {[...new Set([...(allLabels.length > 0 ? allLabels : COMMON_LABELS), ...selectedLabels])].map(label => (
                <button
                  key={label}
                  onClick={() => toggleLabel(label)}
                  className={`px-4 py-2 rounded-xl text-[10px] font-black border transition-all ${selectedLabels.includes(label) ? 'bg-blue-600 border-blue-600 text-white shadow-md' : 'bg-gray-50 border-gray-100 text-gray-500 hover:border-blue-400'}`}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* 3. Main Content Area */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden flex flex-col flex-1 min-h-0">
          {/* Module Header */}
          <div className="px-6 py-5 border-b border-gray-100 flex justify-between items-center bg-gray-50/30">
            <div className="flex items-center gap-2">
              <LayoutList size={18} className="text-blue-600" />
              <h3 className="text-sm font-black text-gray-900 tracking-widest uppercase">交互配置区</h3>
            </div>

            <div className="flex items-center gap-4">
              <div className="flex bg-white border border-gray-200 rounded-xl p-1 shadow-sm">
                <button
                  onClick={() => setActiveTab('LIST')}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-black transition-all ${activeTab === 'LIST' ? 'bg-blue-600 text-white shadow-md' : 'text-gray-400 hover:text-gray-600'}`}
                >
                  <List size={14} /> 列表模式
                </button>
                <button
                  onClick={() => setActiveTab('TIMELINE')}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-black transition-all ${activeTab === 'TIMELINE' ? 'bg-blue-600 text-white shadow-md' : 'text-gray-400 hover:text-gray-600'}`}
                >
                  <Clock size={14} /> 时间轴模式
                </button>
              </div>

              <div className="w-px h-6 bg-gray-200 mx-1"></div>

              <div className="flex items-center gap-2">
                {interactionsList.length > 0 && (
                  <button
                    onClick={handleClearInteractions}
                    className="flex items-center gap-2 px-3 py-2 bg-white border border-gray-200 text-gray-500 rounded-xl text-xs font-black hover:bg-red-50 hover:text-red-500 hover:border-red-200 transition-all"
                    title="清空所有交互"
                  >
                    <Trash2 size={14} />
                  </button>
                )}
              </div>
            </div>
          </div>

          <div className={`flex-1 bg-gray-50/10 ${activeTab === 'LIST' ? 'overflow-y-auto p-8 custom-scrollbar' : 'overflow-hidden flex flex-col'}`}>
            {activeTab === 'LIST' ? (
              <div className="space-y-8 animate-in fade-in duration-300">
                {Object.values(InteractionCategory).map(cat => {
                  const catItems = interactionsList.filter(i => i.type === cat);
                  if (catItems.length === 0) return null;
                  return (
                    <InteractionCategoryGroup key={cat} label={cat} count={catItems.length}>
                      {catItems.map(item => {
                        const state = getInteractionState(item.id);

                        if (item.type === InteractionCategory.QUIZ) {
                          return (
                            <QuizCard
                              key={item.id}
                              id={item.id}
                              title={item.title}
                              mockOptions={item.config?.options?.map((opt: any, idx: number) => ({
                                ...opt,
                                isCorrect: (idx + 1).toString() === item.config?.correctAnswer
                              }))}
                              onDelete={() => handleDeleteInteraction(item.id)}
                              status={state.status}
                              votes={state.votes}
                              isExpanded={state.isExpanded}
                              onStatusChange={(s) => updateInteractionState(item.id, { status: s })}
                              onVotesUpdate={(v) => updateInteractionState(item.id, { votes: v })}
                              onExpandChange={(e) => updateInteractionState(item.id, { isExpanded: e })}
                            />
                          );
                        }

                        if (item.type === InteractionCategory.VOTE) {
                          return (
                            <VoteCard
                              key={item.id}
                              id={item.id}
                              title={item.title}
                              mockOptions={item.config?.options}
                              onDelete={() => handleDeleteInteraction(item.id)}
                              status={state.status as VoteStatus}
                              votes={state.votes}
                              isExpanded={state.isExpanded}
                              onStatusChange={(s) => updateInteractionState(item.id, { status: s })}
                              onVotesUpdate={(v) => updateInteractionState(item.id, { votes: v })}
                              onExpandChange={(e) => updateInteractionState(item.id, { isExpanded: e })}
                            />
                          );
                        }

                        if (item.type === InteractionCategory.DEBATE) {
                          const state = getInteractionState(item.id);
                          const votes = (state.votes as { pro: number; con: number }) || { pro: 0, con: 0 };
                          return <DebateCard key={item.id} id={item.id} title={item.title} proView={item.config?.pro?.view} conView={item.config?.con?.view} onDelete={() => handleDeleteInteraction(item.id)} status={state.status as DebateStatus} votes={votes} isExpanded={state.isExpanded} onStatusChange={(s) => updateInteractionState(item.id, { status: s })} onVotesUpdate={(v) => updateInteractionState(item.id, { votes: v })} onExpandChange={(e) => updateInteractionState(item.id, { isExpanded: e })} />;
                        }
                        if (item.type === InteractionCategory.ONE_STAND) {
                          return <EliminationCard key={item.id} id={item.id} title={item.title} questions={item.config?.questions} mode={item.config?.mode} onDelete={() => handleDeleteInteraction(item.id)} status={state.status as EliminationStatus} isExpanded={state.isExpanded} onStatusChange={(s) => updateInteractionState(item.id, { status: s })} onExpandChange={(e) => updateInteractionState(item.id, { isExpanded: e })} />;
                        }
                        if (item.type === InteractionCategory.GANDI_EMBED) {
                          return <GandiCard key={item.id} id={item.id} title={item.title} projectId={item.config?.projectId} onDelete={() => handleDeleteInteraction(item.id)} status={state.status as GandiStatus} isExpanded={state.isExpanded} onStatusChange={(s) => updateInteractionState(item.id, { status: s })} onExpandChange={(e) => updateInteractionState(item.id, { isExpanded: e })} />;
                        }
                        if (item.type === InteractionCategory.LINK) {
                          return <LinkCard key={item.id} id={item.id} title={item.title} url={item.config?.url} onDelete={() => handleDeleteInteraction(item.id)} status={state.status as LinkStatus} isExpanded={state.isExpanded} onStatusChange={(s) => updateInteractionState(item.id, { status: s })} onExpandChange={(e) => updateInteractionState(item.id, { isExpanded: e })} />;
                        }
                        if (item.type === InteractionCategory.MODEL) {
                          return <ModelCard key={item.id} id={item.id} title={item.title} coverUrl={item.config?.coverUrl} views={item.config?.views} onDelete={() => handleDeleteInteraction(item.id)} status={state.status as ModelStatus} isExpanded={state.isExpanded} onStatusChange={(s) => updateInteractionState(item.id, { status: s })} onExpandChange={(e) => updateInteractionState(item.id, { isExpanded: e })} />;
                        }
                        if (item.type === InteractionCategory.COURSE_SLICE) {
                          return <SliceListCard key={item.id} id={item.id} title={item.title} className={item.config?.className} lessonName={item.config?.lessonName} slices={item.config?.slices} onDelete={() => handleDeleteInteraction(item.id)} status={state.status as SliceListStatus} isExpanded={state.isExpanded} onStatusChange={(s) => updateInteractionState(item.id, { status: s })} onExpandChange={(e) => updateInteractionState(item.id, { isExpanded: e })} />;
                        }

                        return (
                          <InteractionItemView
                            key={item.id}
                            title={item.title}
                            type={item.type}
                            time={item.time}
                            onDelete={() => handleDeleteInteraction(item.id)}
                          />
                        );
                      })}
                    </InteractionCategoryGroup>
                  );
                })}
                {interactionsList.length === 0 && (
                  <div className="py-20 text-center text-gray-400 italic text-sm">暂无交互，请添加</div>
                )}
              </div>
            ) : (
              <div className="flex gap-4 p-6 min-h-0 flex-1 overflow-hidden">
                {/* Track 1: Main Track (Left) */}
                <div className="flex-1 flex flex-col bg-gray-50/30 rounded-2xl border border-gray-100 overflow-hidden shrink-0">
                  <div className="flex items-center justify-between p-4 bg-white border-b border-gray-100 shrink-0">
                    <div className="text-[10px] font-black uppercase text-gray-400 tracking-widest flex items-center gap-2">
                      <Video size={14} /> 主画面轨道 (Main)
                    </div>
                    <div className="flex gap-2">
                      <button onClick={handleAddCamera} className="p-1 px-2.5 bg-teal-50 text-teal-600 rounded-lg text-[10px] font-bold hover:bg-teal-100 flex items-center gap-1 transition-colors">
                        <Monitor size={12} /> 加直播流
                      </button>
                      <button onClick={() => handleAddInteraction(MAIN_CATEGORIES)} className="p-1 px-2.5 bg-blue-50 text-blue-600 rounded-lg text-[10px] font-bold hover:bg-blue-100 flex items-center gap-1 transition-colors">
                        <Plus size={12} /> 加素材
                      </button>
                    </div>
                  </div>

                  <div className="space-y-4 flex-1 overflow-y-auto pr-2 custom-scrollbar p-4 relative bg-gray-50/30">
                    {interactionsList.filter(i => i.track === 'MAIN').length === 0 && (
                      <div className="p-8 border-2 border-dashed border-gray-200 rounded-2xl text-center bg-white/50">
                        <div className="w-12 h-12 bg-gray-50 text-gray-300 rounded-full flex items-center justify-center mb-3 mx-auto">
                          <Video size={24} />
                        </div>
                        <p className="text-xs text-gray-400 font-bold mb-1">暂无主画面内容</p>
                        <p className="text-[10px] text-gray-300">点击上方按钮添加视频或直播流</p>
                      </div>
                    )}

                    {interactionsList.map((item, index) => ({ item, index })).filter(({ item }) => item.track === 'MAIN').map(({ item, index }) => {
                      const childCount = interactionsList.filter(int => int.track !== 'MAIN' && int.parentId === item.id).length;
                      const isSelected = selectedMainTrackId === item.id;
                      const isActive = activeMainTrackId === item.id;
                      const isPlayed = completedMainTrackIds.has(item.id);

                      const visualIndicators = (
                        <>
                          {isSelected && (
                            <>
                              <div className={`absolute -right-[25px] top-1/2 -translate-y-1/2 w-3 h-3 rounded-full border-2 border-white shadow-sm z-30 animate-in zoom-in duration-300 ${isActive ? 'bg-green-500' : 'bg-blue-500'}`}></div>
                              <div className={`absolute right-[-30px] top-1/2 w-[35px] h-[2px] z-10 ${isActive ? 'bg-green-500' : 'bg-blue-500'}`}></div>
                            </>
                          )}
                          {(isSelected || isActive) && (
                            <div className={`absolute left-0 top-1/2 -translate-y-1/2 -translate-x-1/2 w-1.5 h-12 rounded-r-full ${isActive ? 'bg-green-500' : 'bg-blue-500'}`}></div>
                          )}
                        </>
                      );

                      // SPECIFIC RENDERING FOR COURSE SLICE (To match LiveSetupView)
                      if (item.type === InteractionCategory.COURSE_SLICE) {
                        const { sliceIndex, sliceType, lessonName } = item.config || {};
                        return (
                          <div
                            key={item.id}
                            onClick={() => setSelectedMainTrackId(item.id)}
                            className={`relative p-4 rounded-xl border cursor-pointer transition-all duration-300 group mb-4 ${isActive
                              ? 'bg-blue-50/50 border-blue-500 ring-2 ring-blue-100 shadow-md z-20'
                              : isSelected
                                ? 'bg-blue-50/50 border-blue-500 ring-2 ring-blue-100 shadow-md z-20'
                                : isPlayed
                                  ? 'bg-gray-50 border-gray-200 opacity-80 hover:opacity-100'
                                  : 'bg-white border-gray-200 hover:border-blue-300 hover:shadow-sm'
                              } ${draggedItemIndex === index ? 'opacity-50' : ''}`}
                            draggable="true"
                            onDragStart={() => handleDragStart(index)}
                            onDragOver={(e) => handleDragOver(e, index)}
                            onDragEnd={handleDragEnd}
                          >
                            {visualIndicators}
                            {childCount > 0 && (
                              <div className="absolute top-2 right-2 z-10">
                                <span className="flex items-center gap-1 bg-indigo-100 text-indigo-600 px-2 py-1 rounded-full text-[10px] font-black border border-indigo-200 shadow-sm">
                                  <Sparkles size={10} className="fill-current" /> 关联交互 {childCount}
                                </span>
                              </div>
                            )}

                            <div className="flex items-start gap-3 mb-3">
                              <div className={`w-12 h-12 rounded-xl flex shrink-0 items-center justify-center text-white shadow-sm transition-colors ${isActive
                                ? 'bg-blue-500 shadow-blue-200'
                                : isSelected
                                  ? 'bg-indigo-500 shadow-indigo-200'
                                  : 'bg-indigo-50 text-indigo-500 group-hover:bg-indigo-100 group-hover:text-indigo-600'
                                }`}>
                                <div className="flex flex-col items-center leading-none">
                                  <span className="text-[9px] font-bold opacity-70">NO.</span>
                                  <span className="text-sm font-black">{sliceIndex || '?'}</span>
                                </div>
                              </div>
                              <div className="flex-1 min-w-0 pt-0.5">
                                <h4 className={`font-bold text-sm leading-tight truncate mb-1.5 ${isActive ? 'text-blue-900' : isSelected ? 'text-indigo-900' : 'text-gray-900'}`}>{item.title}</h4>
                                <div className="flex items-center gap-2">
                                  <span className="text-[10px] font-bold tracking-wide uppercase text-indigo-600 bg-indigo-50 px-1.5 py-0.5 rounded border border-indigo-100">{sliceType || '切片'}</span>
                                  <span className="text-[10px] font-bold tracking-wide text-gray-400 bg-gray-100 px-1.5 py-0.5 rounded">切片课</span>
                                  {lessonName && (
                                    <span className="text-[10px] font-bold tracking-wide text-blue-600 bg-blue-50 px-1.5 py-0.5 rounded border border-blue-100 max-w-[100px] truncate" title={lessonName}>{lessonName}</span>
                                  )}
                                </div>
                              </div>
                            </div>

                            {/* Footer Controls for Slice */}
                            <div className="flex items-center justify-between pt-3 border-t border-gray-100/50">
                              <div className="flex items-center gap-3">
                                <div className="flex items-center gap-1 text-[10px] text-gray-500 bg-gray-50 px-2 py-1.5 rounded-lg border border-gray-100">
                                  <Clock size={12} className="text-gray-400" />
                                  <span>预计 </span>
                                  <span className="font-bold text-gray-700">{Math.floor((item.duration || 300) / 60)}</span>
                                  <span> min</span>
                                </div>
                                <div className={`flex items-center gap-1 text-[10px] font-bold px-2 py-1.5 rounded-lg border ${item.triggerMode === 'AUTO_TIME' ? 'bg-indigo-50 text-indigo-600 border-indigo-100' : 'bg-gray-50 text-gray-400 border-gray-100'}`}>
                                  <Play size={12} fill={item.triggerMode === 'AUTO_TIME' ? "currentColor" : "none"} />
                                  {item.triggerMode === 'AUTO_TIME' ? '自动' : '手动'}
                                </div>
                              </div>

                              <div className="flex items-center gap-1.5">
                                <button onClick={(e) => { e.stopPropagation(); handleDeleteInteraction(item.id); }} className="p-2 text-gray-300 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors">
                                  <Trash2 size={16} />
                                </button>
                              </div>
                            </div>
                          </div>
                        );
                      }

                      // Generic Render for Other Items (VIDEO, CAMERA, GANDI, LINK)
                      return (
                        <div
                          key={item.id}
                          onClick={() => setSelectedMainTrackId(item.id)}
                          className={`relative p-4 rounded-xl border cursor-pointer transition-all duration-300 group mb-4 ${isActive
                            ? 'bg-green-50/50 border-green-500 ring-2 ring-green-100 shadow-md z-20'
                            : isSelected
                              ? 'bg-blue-50/50 border-blue-500 ring-2 ring-blue-100 shadow-md z-20'
                              : isPlayed
                                ? 'bg-gray-50 border-gray-200 opacity-80 hover:opacity-100'
                                : 'bg-white border-gray-200 hover:border-blue-300 hover:shadow-sm'
                            } ${draggedItemIndex === index ? 'opacity-50' : ''}`}
                          draggable="true"
                          onDragStart={() => handleDragStart(index)}
                          onDragOver={(e) => handleDragOver(e, index)}
                          onDragEnd={handleDragEnd}
                        >
                          {visualIndicators}
                          {childCount > 0 && <div className="absolute top-2 right-2 z-10"><span className="flex items-center gap-1 bg-green-100 text-green-600 px-2 py-1 rounded-full text-[10px] font-black border border-green-200 shadow-sm"><Sparkles size={10} className="fill-current" /> 关联交互 {childCount}</span></div>}

                          <div className="flex items-start gap-3 mb-3">
                            <div className={`w-12 h-12 rounded-xl flex shrink-0 items-center justify-center text-white shadow-sm transition-colors ${isSelected ? 'bg-blue-500 shadow-blue-200' : 'bg-green-100 text-green-500 group-hover:bg-green-200'}`}>
                              {item.category === InteractionCategory.VIDEO ? <Video size={20} /> :
                                item.category === InteractionCategory.CAMERA ? <Monitor size={20} /> :
                                  item.category === InteractionCategory.GANDI_EMBED ? <Sparkles size={20} /> :
                                    <Link2 size={20} />}
                            </div>
                            <div className="flex-1 min-w-0 pt-0.5">
                              <h4 className={`font-bold text-sm leading-tight truncate mb-1.5 ${isSelected ? 'text-blue-900' : 'text-gray-900'}`}>{item.title}</h4>
                              <div className="flex items-center gap-2">
                                <span className="text-[10px] font-bold tracking-wide uppercase text-green-600 bg-green-50 px-1.5 py-0.5 rounded border border-green-100">{item.type}</span>
                              </div>
                            </div>
                          </div>

                          <div className="flex flex-col gap-3 pt-3 border-t border-gray-100/50">
                            {item.type === InteractionCategory.CAMERA && (
                              <div className="grid grid-cols-2 gap-2 mb-1">
                                <div className="bg-gray-50 rounded-lg p-2 border border-gray-200/50">
                                  <label className="text-[9px] font-bold text-gray-400 uppercase mb-1 block">Video</label>
                                  <select className="w-full bg-white text-[10px] font-bold text-gray-700 border border-gray-200 rounded px-1 py-1 outline-none" value={item.config?.videoSource} onClick={(e) => e.stopPropagation()} onChange={(e) => handleUpdateInteraction(item.id, { config: { ...item.config, videoSource: e.target.value } })}>
                                    <option value="default">Default</option><option value="cam-02">Wide</option>
                                  </select>
                                </div>
                                <div className="bg-gray-50 rounded-lg p-2 border border-gray-200/50">
                                  <label className="text-[9px] font-bold text-gray-400 uppercase mb-1 block">Audio</label>
                                  <select className="w-full bg-white text-[10px] font-bold text-gray-700 border border-gray-200 rounded px-1 py-1 outline-none" value={item.config?.audioSource} onClick={(e) => e.stopPropagation()} onChange={(e) => handleUpdateInteraction(item.id, { config: { ...item.config, audioSource: e.target.value } })}>
                                    <option value="default">Default</option><option value="mic-02">Lavalier</option>
                                  </select>
                                </div>
                              </div>
                            )}
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-3">
                                <div className="flex items-center gap-1 text-[10px] text-gray-500 bg-gray-50 px-2 py-1.5 rounded-lg border border-gray-100">
                                  <Clock size={12} className="text-gray-400" />
                                  <span>预计 </span>
                                  <span className="font-bold text-gray-700">{Math.floor((item.duration || 300) / 60)}</span>
                                  <span> min</span>
                                </div>
                              </div>
                              <div className="flex items-center gap-1.5">
                                <button onClick={(e) => { e.stopPropagation(); handleDeleteInteraction(item.id); }} className="p-2 text-gray-300 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors">
                                  <Trash2 size={16} />
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Track 2: Overlay Track (Right) */}
                <div className="flex-1 relative flex flex-col bg-gray-50/30 rounded-2xl border border-gray-100 overflow-hidden">
                  <div className="flex items-center justify-between p-4 bg-white border-b border-gray-100 shrink-0">
                    <div className="flex items-center gap-3">
                      <div className="text-[10px] font-black uppercase text-gray-400 tracking-widest flex items-center gap-2">
                        <Sparkles size={14} /> 叠加交互轨道 (Overlay)
                      </div>
                      {selectedMainTrackId ?
                        <span className="flex items-center gap-1 bg-blue-50 text-blue-600 px-2 py-0.5 rounded text-[10px] font-bold animate-in fade-in slide-in-from-left-2">
                          <Check size={10} />
                          {interactionsList.find(i => i.id === selectedMainTrackId)?.title.slice(0, 10)}...
                        </span> :
                        <span className="bg-gray-100 text-gray-400 px-2 py-0.5 rounded text-[10px] font-bold">未选择主画面</span>
                      }
                    </div>
                    <button
                      disabled={!selectedMainTrackId}
                      onClick={() => handleAddInteraction(OVERLAY_CATEGORIES)}
                      className="px-3 py-1.5 bg-purple-600 text-white rounded-lg text-[10px] font-bold hover:bg-purple-700 flex items-center gap-1 disabled:opacity-30 disabled:cursor-not-allowed shadow-md shadow-purple-100 transition-all active:scale-95"
                    >
                      <Plus size={12} /> 添加交互
                    </button>
                  </div>

                  <div className="space-y-6 relative p-6 flex-1 overflow-y-auto bg-gray-50/30">
                    {!selectedMainTrackId ? (
                      <div className="h-full flex flex-col items-center justify-center text-gray-300 select-none">
                        <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                          <LayoutList size={32} className="opacity-20" />
                        </div>
                        <p className="text-sm font-bold text-gray-400">请先在左侧选择一个主画面内容</p>
                        <p className="text-xs text-gray-300 mt-1">选择后可配置该时间段内的叠加交互</p>
                      </div>
                    ) : (
                      <>
                        {interactionsList.filter(i => i.track !== 'MAIN' && i.parentId === selectedMainTrackId).length === 0 && (
                          <div className="py-12 flex flex-col items-center justify-center text-center border-2 border-dashed border-gray-200 rounded-2xl bg-white/50">
                            <div className="w-12 h-12 bg-purple-50 text-purple-200 rounded-full flex items-center justify-center mb-3">
                              <Sparkles size={24} />
                            </div>
                            <p className="text-xs text-gray-500 font-bold">当前画面暂无叠加交互</p>
                            <button onClick={() => handleAddInteraction(OVERLAY_CATEGORIES)} className="mt-2 text-purple-600 text-xs font-bold hover:underline">点击立即添加</button>
                          </div>
                        )}

                        <div className="space-y-4">
                          {interactionsList.map((item, index) => ({ item, index }))
                            .filter(({ item }) => item.track !== 'MAIN' && item.parentId === selectedMainTrackId)
                            .map(({ item, index }) => {
                              const state = getInteractionState(item.id);
                              const isDragged = draggedItemIndex === index;
                              const dragProps = {
                                draggable: true,
                                onDragStart: () => handleDragStart(index),
                                onDragOver: (e: React.DragEvent) => handleDragOver(e, index),
                                onDragEnd: handleDragEnd,
                                className: `relative group transition-all duration-300 ${isDragged ? 'opacity-40 scale-95' : 'opacity-100'}`
                              };
                              const commonCardProps = {
                                id: item.id,
                                title: item.title,
                                time: item.time,
                                onDelete: () => handleDeleteInteraction(item.id),
                                isExpanded: state.isExpanded,
                                onExpandChange: (e: boolean) => updateInteractionState(item.id, { isExpanded: e }),
                                status: state.status,
                                onStatusChange: (s: any) => updateInteractionState(item.id, { status: s }),
                                dragHandle: <GripVertical size={16} className="text-gray-300 mr-2 cursor-grab hover:text-gray-500" />
                              };

                              if (item.type === InteractionCategory.QUIZ) {
                                return (
                                  <div key={item.id} {...dragProps}>
                                    <QuizCard {...commonCardProps} mockOptions={item.config?.options} votes={state.votes} onVotesUpdate={(v) => updateInteractionState(item.id, { votes: v })} />
                                  </div>
                                );
                              }
                              if (item.type === InteractionCategory.VOTE) {
                                return (
                                  <div key={item.id} {...dragProps}>
                                    <VoteCard {...commonCardProps} mockOptions={item.config?.options} votes={state.votes} onVotesUpdate={(v) => updateInteractionState(item.id, { votes: v })} />
                                  </div>
                                );
                              }
                              if (item.type === InteractionCategory.DEBATE) {
                                return (
                                  <div key={item.id} {...dragProps}>
                                    <DebateCard {...commonCardProps} proView={item.config?.pro?.view} conView={item.config?.con?.view} votes={state.votes} onVotesUpdate={(v) => updateInteractionState(item.id, { votes: v })} />
                                  </div>
                                );
                              }
                              if (item.type === InteractionCategory.ONE_STAND) {
                                return (
                                  <div key={item.id} {...dragProps}>
                                    <EliminationCard {...commonCardProps} questions={item.config?.questions} mode={item.config?.mode} />
                                  </div>
                                );
                              }
                              if (item.type === InteractionCategory.GANDI_EMBED) {
                                return (
                                  <div key={item.id} {...dragProps}>
                                    <GandiCard {...commonCardProps} projectId={item.config?.projectId} />
                                  </div>
                                );
                              }
                              if (item.type === InteractionCategory.LINK) {
                                return (
                                  <div key={item.id} {...dragProps}>
                                    <LinkCard {...commonCardProps} url={item.config?.url} />
                                  </div>
                                );
                              }
                              if (item.type === InteractionCategory.MODEL) {
                                return (
                                  <div key={item.id} {...dragProps}>
                                    <ModelCard {...commonCardProps} coverUrl={item.config?.coverUrl} views={item.config?.views} />
                                  </div>
                                );
                              }
                              if (item.type === InteractionCategory.COURSE_SLICE) {
                                return (
                                  <div key={item.id} {...dragProps}>
                                    <SliceListCard {...commonCardProps} className={item.config?.className} lessonName={item.config?.lessonName} slices={item.config?.slices} />
                                  </div>
                                );
                              }
                              // Fallback just in case
                              return (
                                <div key={item.id} {...dragProps}>
                                  <InteractionItemView title={item.title} type={item.type} time={item.time} onDelete={commonCardProps.onDelete} dragHandle={commonCardProps.dragHandle} />
                                </div>
                              );
                            })}
                        </div>
                      </>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      <ResourceSelectionModal
        isOpen={isSelectionModalOpen}
        onClose={() => setSelectionModalOpen(false)}
        resources={resources}
        onSelect={handleResourceSelected}
        allowedCategories={selectionModalCategoryFilter}
      />
    </div>
  );
};

export default EditInteractionTemplateView;
