
import React, { useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import Sidebar, { ViewType } from './components/Sidebar';
import Header from './components/Header';
import LiveStreamList from './components/LiveStreamList';
import LiveSetupView from './components/LiveSetupView';
import InteractiveResourceList from './components/InteractiveResourceList';
import InteractionTemplateList from './components/InteractionTemplateList';
import CreateInteractiveResourceView from './components/CreateInteractiveResourceView';
import EditInteractionTemplateView from './components/EditInteractionTemplateView';
import { LiveStream, InteractiveResource, InteractionCategory, InteractionTemplate } from './types';
import { db } from './services/db';

// 统一标签数据源
export const COMMON_LABELS = ['数学', '语文', '英语', '理综', '文综', '素质教育', '有奖', '竞赛', '调研', '活动', '互动', '基础', 'AI', '3D'];

const App: React.FC = () => {
  const [isSidebarOpen, setSidebarOpen] = useState(true);
  const [activeView, setActiveView] = useState<ViewType>('ROOM_MANAGEMENT');
  const [selectedStream, setSelectedStream] = useState<LiveStream | null>(null);
  const [isCreatingResource, setIsCreatingResource] = useState(false);
  const [editingResource, setEditingResource] = useState<InteractiveResource | null>(null);

  // 模板管理相关状态
  const [isEditingTemplate, setIsEditingTemplate] = useState(false);
  const [currentEditingTemplate, setCurrentEditingTemplate] = useState<InteractionTemplate | null>(null);

  // 使用 Dexie 获取数据
  const resources = useLiveQuery(() => db.resources.toArray(), []) || [];
  const templates = useLiveQuery(() => db.templates.toArray(), []) || [];

  // Calculate all unique labels from resources, templates, and common labels
  const allLabels = React.useMemo(() => {
    return Array.from(new Set([
      ...COMMON_LABELS,
      ...(resources?.flatMap(r => r.labels) || []),
      ...(templates?.flatMap(t => t.labels) || [])
    ])).sort();
  }, [resources, templates]);

  const handleEnterSetup = (stream: LiveStream) => {
    setSelectedStream(stream);
  };

  const handleBackToList = () => {
    setSelectedStream(null);
  };

  const handleSaveResource = async (resource: InteractiveResource) => {
    await db.resources.put(resource);

    // 级联更新逻辑：更新所有引用了该资源的直播间和模板
    // 1. 更新直播间
    const allStreams = await db.streams.toArray();
    const streamsToUpdate = allStreams.filter(stream =>
      stream.configuredInteractions?.some(item => item.resourceId === resource.id)
    );

    if (streamsToUpdate.length > 0) {
      const updatedStreams = streamsToUpdate.map(stream => ({
        ...stream,
        configuredInteractions: stream.configuredInteractions?.map(item =>
          item.resourceId === resource.id
            ? { ...item, title: resource.name, type: resource.category, config: resource.config } // 更新 config 和 title/type
            : item
        )
      }));
      await db.streams.bulkPut(updatedStreams);
    }

    // 2. 更新模板
    const allTemplates = await db.templates.toArray();
    const templatesToUpdate = allTemplates.filter(tpl =>
      tpl.items?.some(item => item.resourceId === resource.id)
    );

    if (templatesToUpdate.length > 0) {
      const updatedTemplates = templatesToUpdate.map(tpl => ({
        ...tpl,
        items: tpl.items?.map(item =>
          item.resourceId === resource.id
            ? { ...item, title: resource.name, type: resource.category, config: resource.config }
            : item
        )
      }));
      await db.templates.bulkPut(updatedTemplates);
    }

    setIsCreatingResource(false);
    setEditingResource(null);
  };

  const handleSaveTemplate = async (template: InteractionTemplate) => {
    await db.templates.put(template);
    setIsEditingTemplate(false);
    setCurrentEditingTemplate(null);
  };

  const handleEditResource = (resource: InteractiveResource) => {
    setEditingResource(resource);
    setIsCreatingResource(true);
  };

  const handleDeleteResource = async (id: string) => {
    if (window.confirm('确定要删除该交互资源吗？')) {
      await db.resources.delete(id);
    }
  };

  const handleDeleteTemplate = async (id: string) => {
    if (window.confirm('确定要删除该交互模板吗？')) {
      await db.templates.delete(id);
    }
  };

  const handleEditTemplate = (tpl: InteractionTemplate) => {
    setCurrentEditingTemplate(tpl);
    setIsEditingTemplate(true);
  };

  const handleCreateTemplate = () => {
    setCurrentEditingTemplate(null);
    setIsEditingTemplate(true);
  };

  // 保存直播间更新（如交互配置）
  const handleUpdateStream = async (stream: LiveStream) => {
    await db.streams.put(stream);
    setSelectedStream(stream); // 更新本地选中的状态以保持同步
  };

  // 资源编辑视图
  if (isCreatingResource) {
    return (
      <div className="h-screen w-screen bg-[#F0F2F5] overflow-hidden">
        <CreateInteractiveResourceView
          initialResource={editingResource || undefined}
          onBack={() => {
            setIsCreatingResource(false);
            setEditingResource(null);
          }}
          onSave={handleSaveResource}
          allLabels={allLabels}
        />
      </div>
    );
  }

  // 模板编辑视图
  if (isEditingTemplate) {
    return (
      <div className="h-screen w-screen bg-[#F0F2F5] overflow-hidden">
        <EditInteractionTemplateView
          initialTemplate={currentEditingTemplate || undefined}
          resources={resources}
          onBack={() => {
            setIsEditingTemplate(false);
            setCurrentEditingTemplate(null);
          }}
          onSave={handleSaveTemplate}
          allLabels={allLabels}
        />
      </div>
    );
  }

  // 直播间配置视图
  if (selectedStream) {
    return (
      <div className="h-screen w-screen bg-[#F0F2F5] overflow-hidden">
        <LiveSetupView
          stream={selectedStream}
          resources={resources}
          onBack={handleBackToList}
          onSaveStream={handleUpdateStream}
          allLabels={allLabels}
        />
      </div>
    );
  }

  const renderContent = () => {
    switch (activeView) {
      case 'ROOM_MANAGEMENT':
        return (
          <>
            <header className="mb-6 bg-white px-8 py-6 rounded-2xl border border-gray-100 shadow-sm">
              <h1 className="text-2xl font-bold text-gray-800">直播间管理</h1>
              <p className="text-gray-500 text-sm mt-1">管理并监控您的所有直播间资源</p>
            </header>
            <LiveStreamList onEnterSetup={handleEnterSetup} />
          </>
        );
      case 'INTERACTIVE_RESOURCES':
        return (
          <InteractiveResourceList
            resources={resources}
            onAddResource={() => setIsCreatingResource(true)}
            onEditResource={handleEditResource}
            onDeleteResource={handleDeleteResource}
            allLabels={allLabels}
          />
        );
      case 'INTERACTION_TEMPLATES':
        return (
          <InteractionTemplateList
            templates={templates}
            onAddTemplate={handleCreateTemplate}
            onEditTemplate={handleEditTemplate}
            onDeleteTemplate={handleDeleteTemplate}
            allLabels={allLabels}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="flex h-screen bg-[#F0F2F5] overflow-hidden">
      <Sidebar
        isOpen={isSidebarOpen}
        activeView={activeView}
        onViewChange={setActiveView}
      />
      <div className="flex-1 flex flex-col min-w-0">
        <Header
          onToggleSidebar={() => setSidebarOpen(!isSidebarOpen)}
          currentPath={['直播',
            activeView === 'ROOM_MANAGEMENT' ? '直播间管理' :
              activeView === 'INTERACTIVE_RESOURCES' ? '直播交互资源' : '直播交互模板'
          ]}
        />
        <main className="flex-1 overflow-y-auto">
          <div className="p-6 max-w-7xl mx-auto">
            {renderContent()}
          </div>
        </main>
      </div>
    </div>
  );
};

export default App;
